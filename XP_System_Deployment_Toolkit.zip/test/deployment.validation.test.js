const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("Deployment Validation", function () {
  let SentinelToken, QuestClaim, QuestRegistry;
  let deployer;
  const XPType = { GENERAL: 0, COMBAT: 1, CRAFT: 2, SOCIAL: 3, LEADERSHIP: 4 };

  before(async () => {
    [deployer] = await ethers.getSigners();
    const sentinelAddress = process.env.SENTINEL_TOKEN;
    const questClaimAddress = process.env.QUEST_CLAIM;
    const registryAddress = process.env.QUEST_REGISTRY;

    SentinelToken = await ethers.getContractAt("SentinelToken", sentinelAddress);
    QuestClaim = await ethers.getContractAt("QuestClaim", questClaimAddress);
    QuestRegistry = await ethers.getContractAt("QuestRegistry", registryAddress);
  });

  it("should validate role wiring across contracts", async () => {
    const MINTER_ROLE = await SentinelToken.MINTER_ROLE();
    const CLAIM_VERIFIER_ROLE = await QuestClaim.CLAIM_VERIFIER_ROLE();
    const QUEST_CREATOR_ROLE = await QuestRegistry.QUEST_CREATOR_ROLE();
    const QUEST_EXECUTOR_ROLE = await QuestRegistry.QUEST_EXECUTOR_ROLE();

    expect(await SentinelToken.hasRole(MINTER_ROLE, QuestClaim.address)).to.be.true;
    expect(await QuestClaim.hasRole(CLAIM_VERIFIER_ROLE, QuestRegistry.address)).to.be.true;
    expect(await QuestRegistry.hasRole(QUEST_CREATOR_ROLE, deployer.address)).to.be.true;
    expect(await QuestRegistry.hasRole(QUEST_EXECUTOR_ROLE, deployer.address)).to.be.true;
  });

  it("should validate XP emitter is linked", async () => {
    expect(await QuestRegistry.xpEmitter()).to.equal(QuestClaim.address);
  });
});