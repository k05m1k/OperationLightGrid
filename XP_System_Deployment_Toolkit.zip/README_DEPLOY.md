# 🧩 Modular XP System Deployment — Operation Light Grid

This repository contains scripts and tests to deploy and wire the core contracts of the XP System, optimized for DAO governance and multi-chain expansion.

## 📦 Contracts

- `SentinelToken.sol` — ERC1155 Soulbound XP Token
- `QuestClaim.sol` — Intermediary XP emitter with access control
- `QuestRegistry.sol` — Quest system with cooldowns, XP emission, and governance hooks

## 📁 Structure

| Folder | Contents |
|--------|----------|
| `scripts/` | Deployment and wiring scripts |
| `test/` | Contract validation and integration tests |
| `deployments/` | Auto-generated JSON files with deployed addresses |

## 🛠️ Setup

1. Copy `.env.template` to `.env`
2. Fill in the values based on your target network

```bash
cp .env.template .env
```

3. Install dependencies

```bash
npm install
```

## 🚀 Deployment

Deploy each contract independently:

```bash
npx hardhat run scripts/deploy_sentinel.js --network optimism
npx hardhat run scripts/deploy_quest_claim.js --network optimism
npx hardhat run scripts/deploy_quest_registry.js --network optimism
```

Then wire them together:

```bash
npx hardhat run scripts/wiring_script.js --network optimism
```

## ✅ Validation

Test the roles and links:

```bash
npx hardhat test test/deployment.validation.test.js
```

## 🔐 Environment Variables

See `.env.template` for all required values.

## 🧪 Optional Flags

- `RENOUNCE_ADMIN=true` — renounces `DEFAULT_ADMIN_ROLE` from the deployer
- `BASE_URI=https://your-metadata-source.com/{id}.json`

---

Crafted for **DAO resilience**, **multi-chain support**, and **on-chain XP systems**.  
Join the grid.